#!/bin/bash
docker build --rm -t lavad -f docker/Dockerfile .
