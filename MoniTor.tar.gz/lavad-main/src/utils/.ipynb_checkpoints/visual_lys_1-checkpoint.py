import matplotlib.pyplot as plt
import numpy as np
import os
import json

# 假设的视频名称
video_name = 'Real-World Video I'

# def extract_new_scores_from_json(json_file_path):
#     try:
#         with open(json_file_path, 'r') as file:
#             data = json.load(file)
#         new_scores = [item["new_score"] for item in data]
#         return new_scores
#     except FileNotFoundError:
#         print(f"文件 {json_file_path} 不存在。")
#         return []
#     except json.JSONDecodeError:
#         print(f"文件 {json_file_path} 不是有效的 JSON 格式。")
#         return []

# # 假设你的 JSON 文件路径
# json_file_path = "autodl-tmp/lavad-main/ucf_crime2/scores/raw/llama-2-13b-chat/opt-6.7b-coco+opt-6.7b+flan-t5-xxl+flan-t5-xl+flan-t5-xl-coco/baseline+all-forget-3/Arson016_x264.json"
# scores = extract_new_scores_from_json(json_file_path)

scores = [0, 0, 0, 0, 0, 0, 0, 0, 0.1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.1, 0, 0, 0, 0, 0, 0, 0, 0.9, 1, 0.9, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
# scores = [0, 0, 0.1, 0.1, 0.2, 0.2, 0.2, 0.1, 0.1, 0.2, 0.2, 0.1, 0.7, 0.7, 0.7, 0.7, 0.7, 0.7, 0.7, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.8, 0.9, 0.9, 0.8, 0.9, 0.9, 0.9, 0.9, 0.6, 0.6, 0.6, 0.8, 0.8, 0.7, 0.8, 0.8, 0.8, 0.9, 0.9, 0.9, 0.8]
# scores = [0, 0.1, 0.2, 0.2, 0.2, 0.2, 0.2, 0.3, 0.3, 0.3, 0.3, 0.3, 0.3, 0.6, 0.2, 0.5, 0.5, 0.6, 0.6, 0.5, 0.6, 0.5, 0.6, 0.6, 0.6, 0.8, 0.8, 0.4, 0.6, 0.8, 0.8, 0.8, 0.8, 0.8, 0.8, 0.8, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.8, 0.9, 0.9, 0.9, 0.9, 0.3, 0.7, 0.8, 0.9, 0.8, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.3, 0.2, 0.7, 0.8, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.8, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.9, 0.8, 0.8, 0.8, 0.8, 0.8, 0.8]

num = 806
labels = [0] * num
l = 480
r = 540
for i in range(l-1, r):
    labels[i] = 1
# num = 780
# labels = [0] * num
# l = 180
# r = 768
# for i in range(l-1, r):
#     labels[i] = 1
# num = 2712
# labels = [0] * num
# l = 250
# r = 2700
# for i in range(l-1, r):
#     labels[i] = 1

scores = np.repeat(scores, 16)
scores = scores[: num]

# print(scores)
# print(len(scores))
# print(labels)
# print(len(labels))

# 创建图形
fig = plt.figure(figsize=(12, 8))
gs = plt.GridSpec(2, 2, width_ratios=[1, 1], height_ratios=[1, 1])
# gs = plt.GridSpec(1, 1, width_ratios=[1, 1], height_ratios=[1, 1])

# ax1 = plt.subplot(gs[0, 0])
# ax2 = plt.subplot(gs[0, 1])
ax3 = plt.subplot(gs[1, :])
# ax3 = plt.subplot(gs[0:, :])

# 设置 ax3 的内容
x = np.arange(len(scores))
ax3.plot(x, scores, color="#4e79a7", linewidth=1)
ymin, ymax = 0, 1
xmin, xmax = 0, len(scores)
ax3.set_xlim([xmin, xmax])
ax3.set_ylim([ymin, ymax])
title = video_name
ax3.text(0.02, 0.90, title, fontsize=16, transform=ax3.transAxes)
for y_value in [0.25, 0.5, 0.75]:
    ax3.axhline(y=y_value, color="grey", linestyle="--", linewidth=0.8)
ax3.set_yticks([0.25, 0.5, 0.75])
ax3.tick_params(axis="y", labelsize=16)
ax3.set_ylabel("Anomaly score", fontsize=18)
ax3.set_xlabel("Frame number", fontsize=18)

start_idx = None
for frame_idx, label in enumerate(labels):
    if label!= 0 and start_idx is None:
        start_idx = frame_idx
    elif label == 0 and start_idx is not None:
        rect = plt.Rectangle((start_idx, ymin), frame_idx - start_idx, ymax - ymin, color="#e15759", alpha=0.5)
        ax3.add_patch(rect)
        start_idx = None

if start_idx is not None:
    rect = plt.Rectangle((start_idx, ymin), len(labels) - start_idx, ymax - ymin, color="#e15759", alpha=0.5)
    ax3.add_patch(rect)

# # 设置 ax1 和 ax2 的标题（这里只是占位，你可以根据实际情况设置内容）
# ax1.set_title("Video frame", fontsize=18)
# ax2.set_title("Temporal summary", fontsize=18)

# 显示图形
plt.tight_layout()
plt.show()
current_directory = os.path.dirname(os.path.abspath(__file__))
# 保存图片到当前文件所在目录
output_image_path = os.path.join(current_directory, f"{video_name}.png")
fig.savefig(output_image_path)