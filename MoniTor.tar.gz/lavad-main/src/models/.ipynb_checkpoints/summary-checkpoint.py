import argparse
import json
from pathlib import Path
from typing import List

import numpy as np
from tqdm import tqdm

from src.data.video_record import VideoRecord
from src.utils.path_utils import find_unprocessed_videos
from zhipuai import ZhipuAI

class GLMSummarizer:
    def __init__(
        self,
        api_key,
        root_path,
        annotationfile_path,
        batch_size,
        frame_interval,
        context_prompt,
        format_prompt,
        output_summary_dir,
        captions_dir,
        temperature,
        top_p,
        max_gen_len,
    ):
        self.api_key = api_key
        self.root_path = root_path
        self.annotationfile_path = annotationfile_path
        self.batch_size = batch_size
        self.frame_interval = frame_interval
        self.context_prompt = context_prompt
        self.format_prompt = format_prompt
        self.output_summary_dir = output_summary_dir
        self.captions_dir = captions_dir
        self.temperature = temperature
        self.top_p = top_p
        self.max_gen_len = max_gen_len

        self.client = ZhipuAI(api_key=self.api_key)

    def _prepare_dialogs(self, captions, batch_frame_idxs):
        prompt = self.context_prompt + " " + self.format_prompt
        batch_clip_caption = [f"{captions[str(idx)]}." for idx in batch_frame_idxs]

        dialogs = [
            [
                {"role": "system", "content": prompt},
                {"role": "user", "content": clip_caption},
            ]
            for clip_caption in batch_clip_caption
        ]
        return dialogs

    def _summarize_captions(self, video, video_captions):
        video_summaries = {}

        for batch_start_frame in tqdm(
            range(0, video.num_frames, self.batch_size * self.frame_interval),
            desc=f"Processing {video.path}",
            unit="batch",
        ):
            batch_end_frame = min(
                batch_start_frame + (self.batch_size * self.frame_interval), video.num_frames
            )
            batch_frame_idxs = range(batch_start_frame, batch_end_frame, self.frame_interval)

            dialogs = self._prepare_dialogs(video_captions, batch_frame_idxs)

            results = []
            for dialog in dialogs:
                response = self.client.chat.completions.create(
                    model="glm-4-flash",
                    messages=dialog,
                    stream=False,
                    timeout=30,
                    temperature=self.temperature,
                    top_p=self.top_p,
                )
                results.append(response.choices[0].message.content.strip())

            for result, frame_idx in zip(results, batch_frame_idxs):
                video_summaries[str(frame_idx)] = result

        return video_summaries

    def process_video(self, video):
        video_name = Path(video.path).name

        # Summarize captions
        video_caption_path = Path(self.captions_dir) / f"{video_name}.json"
        try:
            with open(video_caption_path) as f:
                video_captions = json.load(f)
        except FileNotFoundError:
            print(f"Captions not found for video {video_name}")
            return
        except json.JSONDecodeError:
            print(f"Failed to parse captions for video {video_name}")
            return

        video_summaries = self._summarize_captions(video, video_captions)

        output_path = Path(self.output_summary_dir) / f"{video_name}_summary.json"
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "w") as f:
            json.dump(video_summaries, f, indent=4)

        print(f"Summary successfully saved to {output_path}")

def run(
    root_path,
    annotationfile_path,
    batch_size,
    frame_interval,
    context_prompt,
    format_prompt,
    output_summary_dir,
    captions_dir,
    api_key,
    temperature,
    top_p,
    max_gen_len,
    resume,
    pathname,
    num_jobs,
    job_index,
):
    output_summary_dir = Path(output_summary_dir)
    output_summary_dir.mkdir(parents=True, exist_ok=True)
    with open(output_summary_dir / "context_prompt.txt", "w") as f:
        f.write(context_prompt)
    with open(output_summary_dir / "format_prompt.txt", "w") as f:
        f.write(format_prompt)

    video_list = [VideoRecord(x.strip().split(), root_path) for x in open(annotationfile_path)]
    video_list = list(np.array_split(video_list, num_jobs)[job_index])
    if resume:
        video_list = find_unprocessed_videos(
            video_list, output_summary_dir, pathname
        )

    glm_summarizer = GLMSummarizer(
        api_key=api_key,
        root_path=root_path,
        annotationfile_path=annotationfile_path,
        batch_size=batch_size,
        frame_interval=frame_interval,
        context_prompt=context_prompt,
        format_prompt=format_prompt,
        output_summary_dir=output_summary_dir,
        captions_dir=captions_dir,
        temperature=temperature,
        top_p=top_p,
        max_gen_len=max_gen_len,
    )

    for video in video_list:
        glm_summarizer.process_video(video)

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root_path", type=str, required=True)
    parser.add_argument("--annotationfile_path", type=str, required=True)
    parser.add_argument("--batch_size", type=int, default=1)
    parser.add_argument("--frame_interval", type=int, default=16)
    parser.add_argument("--context_prompt", type=str)
    parser.add_argument("--format_prompt", type=str)
    parser.add_argument("--output_summary_dir", type=str)
    parser.add_argument("--captions_dir", type=str)
    parser.add_argument("--api_key", type=str, required=True)
    parser.add_argument("--temperature", type=float, default=0.6)
    parser.add_argument("--top_p", type=float, default=0.9)
    parser.add_argument("--max_gen_len", type=int, default=256)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--pathname", type=str, default="*.json")
    parser.add_argument("--num_jobs", type=int, default=1)
    parser.add_argument("--job_index", type=int, default=0)

    return parser.parse_args()

if __name__ == "__main__":
    args = parse_args()
    run(
        root_path=args.root_path,
        annotationfile_path=args.annotationfile_path,
        batch_size=args.batch_size,
        frame_interval=args.frame_interval,
        context_prompt=args.context_prompt,
        format_prompt=args.format_prompt,
        output_summary_dir=args.output_summary_dir,
        captions_dir=args.captions_dir,
        api_key=args.api_key,
        temperature=args.temperature,
        top_p=args.top_p,
        max_gen_len=args.max_gen_len,
        resume=args.resume,
        pathname=args.pathname,
        num_jobs=args.num_jobs,
        job_index=args.job_index,
    )